package java2project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TaskManager extends JFrame {

    public TaskManager() {
        // ***** Window setting *****
        setTitle("Task Manager");
        setSize(550, 330);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // ***** Create MenuBar *****
        JMenuBar menuBar = new JMenuBar();

        // Create "File" menu
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Exit the program
                System.exit(0);
            }
        });
        fileMenu.add(exitItem);

        // Create "Help" menu
        JMenu helpMenu = new JMenu("Help");
        
        // Menu item for Email Help
        JMenuItem emailHelpItem = new JMenuItem("Email Help");
        emailHelpItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Show Email Help message
                JOptionPane.showMessageDialog(TaskManager.this, 
                    "For help, please email: helpStudyManage@gmail.com", 
                    "Help Email", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Menu item for Phone Help
        JMenuItem phoneHelpItem = new JMenuItem("Phone Help");
        phoneHelpItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Show Phone Help message
                JOptionPane.showMessageDialog(TaskManager.this, 
                    "For urgent assistance, call: 0532633708", 
                    "Help Number", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Add menu items to Help menu
        helpMenu.add(emailHelpItem);
        helpMenu.add(phoneHelpItem);

        // Add menus to the menu bar
        menuBar.add(fileMenu);
        menuBar.add(helpMenu);

        // Set the menu bar for the frame
        setJMenuBar(menuBar);

        // *****  GridBagLayout  *****
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBorder(BorderFactory.createLineBorder(new Color(159, 9, 149), 5));
        contentPanel.setBackground(new Color(240, 240, 240));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 10, 10); // top, left, bottom, right

        // ***** Label *****
        JLabel headerLabel = new JLabel("Choose what you want to do", SwingConstants.CENTER);
        headerLabel.setFont(new Font("Bell MT", Font.BOLD, 22));
        headerLabel.setForeground(Color.BLACK);
        gbc.gridx = 0; // column
        gbc.gridy = 1; // row
        gbc.gridwidth = 2; // horizontal span
        gbc.anchor = GridBagConstraints.NORTH; // align to the top
        contentPanel.add(headerLabel, gbc);

        // ***** Image Label *****
        // Load and add the image
        ImageIcon icon = new ImageIcon(getClass().getResource("Photo.jpeg"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(150, 100, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel imageLabel = new JLabel(scaledIcon);

        gbc.gridy = 2;
        contentPanel.add(imageLabel, gbc);

        // ***** Buttons *****
        JButton addTaskButton, listTaskButton;
        addTaskButton = new JButton("Add Task");
        listTaskButton = new JButton("List Task");
        Font buttonFont = new Font("Bell MT", Font.BOLD, 17);
        addTaskButton.setFont(buttonFont);
        listTaskButton.setFont(buttonFont);
        addTaskButton.setForeground(new Color(159, 9, 149));
        listTaskButton.setForeground(new Color(159, 9, 149));
        Dimension buttonSize = new Dimension(120, 40);
        addTaskButton.setPreferredSize(buttonSize);
        listTaskButton.setPreferredSize(buttonSize);

        gbc.gridx = 0; // first column
        gbc.gridy = 3; // 4th row
        gbc.gridwidth = 1; // one cell
        gbc.anchor = GridBagConstraints.LINE_END; // align to the right
        contentPanel.add(addTaskButton, gbc);

        gbc.gridx = 1; // second column
        gbc.gridy = 3; // 4th row
        gbc.anchor = GridBagConstraints.LINE_START; // align to the left
        contentPanel.add(listTaskButton, gbc);

        add(contentPanel, BorderLayout.CENTER);

        // ***** Action of buttons *****
        addTaskButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               
                new AddTask(); 
            }
        });

        listTaskButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               
                new TaskList(); 
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new TaskManager();
    }
}
