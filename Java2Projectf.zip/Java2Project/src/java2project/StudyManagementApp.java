package java2project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StudyManagementApp extends JFrame {

       
    public StudyManagementApp() {
        
        // *****window setting****
        
        setTitle("Study Management Program");
        setSize(550, 330); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(BorderFactory.createLineBorder(new Color(159, 9, 149), 5));//color in RGP,thin of color
        contentPanel.setBackground(new Color(240, 240, 240)); 

        int topSpacing = 50; 
        contentPanel.add(Box.createRigidArea(new Dimension(0, topSpacing))); //bettwen panle and component
        int verticalSpacing = 10;  //bettwen component
        
        // *****addd title*****
        JLabel welcomeLabel = new JLabel("Welcome to the Study Management Program!");
        welcomeLabel.setFont(new Font("Bell MT", Font.BOLD, 21));
        welcomeLabel.setForeground(Color.BLACK);  
        welcomeLabel.setAlignmentX(CENTER_ALIGNMENT);  
        contentPanel.add(welcomeLabel);
        contentPanel.add(Box.createRigidArea(new Dimension(0, verticalSpacing)));  

        // *****add lable*****
        JLabel descriptionLabel1 = new JLabel("We are excited to offer you an innovative tool to help you organize ");
        descriptionLabel1.setFont(new Font("Bell MT", Font.PLAIN, 18));
        descriptionLabel1.setForeground(Color.BLACK);  
        descriptionLabel1.setAlignmentX(CENTER_ALIGNMENT);  
        contentPanel.add(descriptionLabel1);
        contentPanel.add(Box.createRigidArea(new Dimension(0, verticalSpacing)));

        JLabel descriptionLabel2 = new JLabel("and track your study tasks effortlessly. With this program, you can ");
        descriptionLabel2.setFont(new Font("Bell MT", Font.PLAIN, 18));
        descriptionLabel2.setForeground(Color.BLACK);  
        descriptionLabel2.setAlignmentX(CENTER_ALIGNMENT);
        contentPanel.add(descriptionLabel2);
        contentPanel.add(Box.createRigidArea(new Dimension(0, verticalSpacing)));

        JLabel descriptionLabel3 = new JLabel("related to each subject, keeping you organized and on top");
        descriptionLabel3.setFont(new Font("Bell MT", Font.PLAIN, 18));
        descriptionLabel3.setForeground(Color.BLACK);  
        descriptionLabel3.setAlignmentX(CENTER_ALIGNMENT);
        contentPanel.add(descriptionLabel3);
        contentPanel.add(Box.createRigidArea(new Dimension(0, verticalSpacing)));

        JLabel descriptionLabel4 = new JLabel("of your studies at all times");
        descriptionLabel4.setFont(new Font("Bell MT", Font.PLAIN, 18));
        descriptionLabel4.setForeground(Color.BLACK);  
        descriptionLabel4.setAlignmentX(CENTER_ALIGNMENT);
        contentPanel.add(descriptionLabel4);
        contentPanel.add(Box.createRigidArea(new Dimension(0, verticalSpacing)));

        //*****add button******
        JButton startButton = new JButton("Click to Start");
        startButton.setFont(new Font("Bell MT", Font.BOLD, 17));
        startButton.setForeground(new Color(159, 9, 149));  
        startButton.setAlignmentX(CENTER_ALIGNMENT); 
        startButton.addActionListener(new startButtonActtion());
        contentPanel.add(startButton);
        int bottomSpacing = 30;   
        contentPanel.add(Box.createRigidArea(new Dimension(0, bottomSpacing)));  

         
        add(contentPanel);

        setVisible(true);
    }
    
    private class startButtonActtion implements ActionListener {
        public void actionPerformed(ActionEvent e){
            //open second window to start program 
            TaskManager manager= new TaskManager();
            manager.setVisible(true);
            // JOptionPane.showMessageDialog(null,"correct action");
        }
    }

    public static void main(String[] args) {

        new StudyManagementApp();
    }
}
