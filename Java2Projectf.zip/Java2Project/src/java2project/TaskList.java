package java2project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class TaskList {

    public TaskList() {
        // Set up the frame
        JFrame frame = new JFrame("Task List");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(550, 330);
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));

        // Create main panel with custom styling
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createLineBorder(new Color(159, 9, 149), 5));
        panel.setBackground(new Color(240, 240, 240));

        // Title label
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        JLabel titleLabel = new JLabel("Task List");
        titleLabel.setFont(new Font("Bell MT", Font.BOLD, 30));
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(titleLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Subject panel with JComboBox
        JPanel subjectPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel subjectLabel = new JLabel("The subject:");
        subjectLabel.setFont(new Font("Bell MT", Font.PLAIN, 18));
        JComboBox<String> subjectComboBox = new JComboBox<>(new String[] {"Math", "CS", "AI"});
        subjectPanel.add(subjectLabel);
        subjectPanel.add(subjectComboBox);
        panel.add(subjectPanel);

        // Time panel with JTextField
        JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel timeLabel = new JLabel("The time:");
        timeLabel.setFont(new Font("Bell MT", Font.PLAIN, 18));
        JTextField timeField = new JTextField(15);
        timePanel.add(timeLabel);
        timePanel.add(timeField);
        panel.add(timePanel);

        // Tasks panel with JTextField
        JPanel tasksPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel tasksLabel = new JLabel("The tasks:");
        tasksLabel.setFont(new Font("Bell MT", Font.PLAIN, 18));
        JTextField tasksField = new JTextField(15);
        tasksPanel.add(tasksLabel);
        tasksPanel.add(tasksField);
        panel.add(tasksPanel);

        // Add action listener to subjectComboBox
        subjectComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedSubject = (String) subjectComboBox.getSelectedItem();
                loadTaskData(selectedSubject, timeField, tasksField);
            }
        });

        // Back button
        JButton backButton = new JButton("Back");
        backButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        backButton.setMaximumSize(new Dimension(80, 25)); // Make the button smaller
        panel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacer
        panel.add(backButton);

        // Back button action
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close the current frame
            }
        });

        // Add panel to the frame and make it visible
        frame.add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private static void loadTaskData(String subject, JTextField timeField, JTextField tasksField) {
        boolean taskFound = false;  // Flag to check if a task is found
        ArrayList<String[]> taskList = new ArrayList<>();  // List to store all tasks for each subject

        try (BufferedReader reader = new BufferedReader(new FileReader("tasks.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals(subject)) {
                    taskList.add(parts);  // Add task to list if the subject matches
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // If any tasks are found for the subject, load the last one (latest task)
        if (!taskList.isEmpty()) {
            String[] latestTask = taskList.get(taskList.size() - 1);  // Get the last task added
            timeField.setText(latestTask[1]);
            tasksField.setText(latestTask[2]);
            taskFound = true;  // Task found for the subject
        }

        // If no task is found, clear the text fields and show a message
        if (!taskFound) {
            timeField.setText("");
            tasksField.setText("");
            JOptionPane.showMessageDialog(null, "No task found for the selected subject.", "No Task", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new TaskList(); // Call constructor to set up and display the window
    }
}
