/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java2project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class AddTask extends JFrame {

    public AddTask() {
        // Set up the frame
        setTitle("Add Task");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(550, 330);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        // Create main panel with custom styling
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createLineBorder(new Color(159, 9, 149), 5));
        panel.setBackground(new Color(240, 240, 240));

        // Title label
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        JLabel titleLabel = new JLabel("Choose the subject and the time for the task");
        titleLabel.setFont(new Font("Bell MT", Font.BOLD, 21));
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(titleLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Subject panel
        JPanel subjectPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel subjectLabel = new JLabel("Choose the subject:");
        JComboBox<String> subjectComboBox = new JComboBox<>(new String[]{"Math", "CS", "AI"});
        subjectPanel.add(subjectLabel);
        subjectPanel.add(subjectComboBox);
        panel.add(subjectPanel);

        // Time panel
        JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel timeLabel = new JLabel("Choose the time:");
        JComboBox<String> timeComboBox = new JComboBox<>(new String[]{"8:00-9:00", "10:00-11:00", "12:00-1:00"});
        timePanel.add(timeLabel);
        timePanel.add(timeComboBox);
        panel.add(timePanel);

        // Task panel with Save button
        JPanel taskPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel taskLabel = new JLabel("Write the task:");
        JTextField taskField = new JTextField(15);
        JButton saveButton = new JButton("Save");
        taskPanel.add(taskLabel);
        taskPanel.add(taskField);
        taskPanel.add(saveButton);
        panel.add(taskPanel);

        // Save button action
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String task = taskField.getText();
                if (task.isEmpty()) {
                    // Show message if task is not entered
                    JOptionPane.showMessageDialog(AddTask.this, "Please enter a task before saving.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    saveTaskToFile((String) subjectComboBox.getSelectedItem(),
                            (String) timeComboBox.getSelectedItem(),
                            task);
                    JOptionPane.showMessageDialog(AddTask.this, "Task saved!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Back button
        JButton backButton = new JButton("Back");
        backButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        backButton.setMaximumSize(new Dimension(80, 25)); // Make the button smaller
        panel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacer
        panel.add(backButton);

        // Back button action
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the current frame
            }
        });

        // Add panel to the frame and make it visible
        add(panel, BorderLayout.CENTER);
        setVisible(true);
    }

    private static void saveTaskToFile(String subject, String time, String task) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("tasks.txt", true)
)) {
            writer.write(subject + "," + time + "," + task + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new AddTask(); // Call constructor to set up and display the window
    }
}
